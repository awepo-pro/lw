---
title: KV Cache
created: 2026-10-01
updated: 2026-10-01
type: concept
tags: [inference]
---

The KV cache stores keys and values.
