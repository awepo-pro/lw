# SCHEMA

## Domain

synthetic

## Tags

- `inference` — a tag.
