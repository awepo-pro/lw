synthetic raw note
